let randomNumber = Math.floor(Math.random() * 10) + 1;
      const guesses = document.querySelector('.guesses');
      const lastResult = document.querySelector('.lastResult');
      const lowOrHi = document.querySelector('.lowOrHi');
      const guessSubmit = document.querySelector('.guessSubmit');
      const guessField = document.querySelector('.guessField');
      let guessCount = 1;
      let resetButton;
      

      function checkGuess() {
        const userGuess = Number(guessField.value);
        if (userGuess >= 1 && userGuess <=10) {
            if (guessCount === 1) {
            guesses.textContent = 'Ваши попытки: ';
            }

            guesses.textContent += userGuess + ' ';

            if (userGuess === randomNumber) {
                lastResult.textContent = 'Ура ты угадал число';
                lastResult.style.backgroundColor = 'green';
                lowOrHi.textContent = '';
                setGameOver();
            } else if (guessCount === 5) {
                lastResult.textContent = 'Ты не угадал число ;(';
                lowOrHi.textContent = '';
                setGameOver();
            } else {
                lastResult.textContent = 'Неверно';
                lastResult.style.backgroundColor = 'red';
            if(userGuess < randomNumber) {
                lowOrHi.textContent = 'Загаданое число больше вашего' ;
            } else if(userGuess > randomNumber) {
                lowOrHi.textContent = 'загаданное число меньше вашего';
          }
        }
        } else{
            lastResult.textContent = 'Что-то тут не так. Нужно угадать число от 1 до 10 включительно :) Давай начнем сначала'
            lastResult.style.background = ''
            setGameOver()
        }
        

        guessCount++;
        guessField.value = '';
        guessField.focus();
      }

      guessSubmit.addEventListener('click', checkGuess);

      function setGameOver() {
        guessField.disabled = true;
        guessSubmit.disabled = true;
        resetButton = document.createElement('button');
        resetButton.textContent = 'Начать новую игру';
        resetButton.style.background = 'coral'
        resetButton.style.padding = '10px';
        document.body.appendChild(resetButton);
        resetButton.addEventListener('click', resetGame);
      }

      function resetGame() {
        guessCount = 1;
        const resetParas = document.querySelectorAll('.resultParas p');
        for (const resetPara of resetParas) {
          resetPara.textContent = '';
        }

        resetButton.parentNode.removeChild(resetButton);
        guessField.disabled = false;
        guessSubmit.disabled = false;
        guessField.value = '';
        guessField.focus();
        lastResult.style.backgroundColor = 'white';
        randomNumber = Math.floor(Math.random() * 10) + 1;
      }