// pages/About.jsx 

import React from 'react'; 

 
function AboutUs() {
    return (
      <div>
        <h1>О нас</h1>
      </div>
    )
  }

export default About; 