import React from 'react'

function MakeRequest() {
  return (
    <div>
      <h1>Сделать запрос</h1>
    </div>
  )
}

export default MakeRequest