import React from 'react'

function Calculation() {
  return (
    <div>
      <h1>Расчет</h1>
    </div>
  )
}

export default Calculation