import React from 'react'

function Products() {
  return (
    <div>
      <h1>Продукты</h1>
    </div>
  )
}


export default Products; 