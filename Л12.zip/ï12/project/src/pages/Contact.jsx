import React from 'react'

function Contacts() {
  return (
    <div>
      <h1>Контакты</h1>
    </div>
  )
}

export default Contacts