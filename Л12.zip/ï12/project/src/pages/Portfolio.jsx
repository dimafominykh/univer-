import React from 'react'

function Portfolio() {
  return (
    <div>
      <h1>Фото</h1>
    </div>
  )
}

export default Portfolio