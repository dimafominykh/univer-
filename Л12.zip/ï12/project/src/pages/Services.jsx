import React from 'react'

function Services() {
  return (
    <div>
      <h1>Сервис</h1>
    </div>
  )
}

export default Services